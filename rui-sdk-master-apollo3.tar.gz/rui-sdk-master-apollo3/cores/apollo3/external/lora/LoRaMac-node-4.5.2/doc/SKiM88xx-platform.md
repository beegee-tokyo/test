# SKiM88xx platforms support documents

The supported SKiM88xx platforms are:
1. [SK-iM880B - Long Range Radio Starter Kit](https://wireless-solutions.de/products/starterkits/sk-im880b.html)
2. [SK-iM980A - Long Range Radio Starter Kit](https://wireless-solutions.de/products/long-range-radio/im980a.html)
3. [SK-iM881A-XL - Long Range Radio Starter Kit](https://wireless-solutions.de/products/long-range-radio/im881a-xl.html)
